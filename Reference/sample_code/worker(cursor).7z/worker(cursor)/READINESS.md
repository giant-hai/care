# Project Readiness Review

## Summary

The project is **ready to run** after the fixes applied below. It requires Java 17+, Maven, Python 3.8+, and Docker (for RabbitMQ) to be installed.

---

## Fixes Applied

### 1. Missing Dockerfiles (Critical)

**Issue:** `docker-compose.yml` referenced `build: .` and `build: ./python_worker` but no Dockerfiles existed.

**Fix:** Added:
- `Dockerfile` – Multi-stage build for Spring Boot (Maven build → JRE runtime)
- `python_worker/Dockerfile` – Python 3.11 image with Celery and RabbitMQ support

### 2. Celery Broker URL (Docker)

**Issue:** `celery_app.py` used a hardcoded `localhost:5672` broker, which fails when the Celery worker runs in Docker (RabbitMQ is on hostname `rabbitmq`).

**Fix:** Celery now reads `CELERY_BROKER_URL` from the environment, with a fallback to `localhost` for local development.

### 3. Spring App in Docker

**Issue:** The Spring app in Docker needs to point Celery broker at `rabbitmq` instead of `localhost`.

**Fix:** Added `CELERY_BROKER: amqp://guest:guest@rabbitmq:5672//` to the `spring-app` service in `docker-compose.yml`.

### 4. README Typo

**Fix:** Removed stray "text" before the project structure code block.

---

## How to Run

### Option A: Fully local (no Docker at all)

This assumes you install RabbitMQ **directly on your machine**.

1. **Install and start RabbitMQ locally**
   - Download and install Erlang and RabbitMQ for your OS (on Windows, use the official installer).
   - Start the RabbitMQ service (Windows Service Manager or `rabbitmq-server` command).
   - Make sure it is listening on:
     - AMQP: `localhost:5672`
     - (Optional) Management UI: `localhost:15672`
   - Default credentials: `guest` / `guest`.

2. **Run the Spring Boot application**
   - From the project root:
     ```bash
     mvn spring-boot:run
     ```
   - This uses `src/main/resources/application.yml`, which is already configured for:
     - `spring.rabbitmq.host: localhost`
     - `celery.broker: amqp://guest:guest@localhost:5672//`

3. **Run the Celery worker**
   - In a separate terminal:
     ```bash
     cd python_worker
     pip install -r requirements.txt
     celery -A celery_app worker -Q reward-queue --loglevel=info
     ```
   - `celery_app.py` will default to `amqp://guest:guest@localhost:5672//` when `CELERY_BROKER_URL` is not set, which matches the local RabbitMQ.

4. **Test the API**
   - Spring Boot runs on `http://localhost:8080`.
   - Use the curl commands in **Quick API Test** below.

### Option B: Docker Compose (recommended for consistent environment)

```bash
docker-compose up --build
```

- RabbitMQ: http://localhost:15672 (guest/guest)
- Spring Boot API: http://localhost:8080
- Celery worker runs in the background

---

## Prerequisites Checklist

| Requirement | Purpose |
|-------------|---------|
| Java 17+ | Spring Boot application |
| Maven 3.6+ | Build Java project |
| Python 3.8+ | Celery worker |
| Docker | RabbitMQ + optional full stack |

---

## Known Limitations

1. **Bonus not persisted:** The Celery `process_reward` task only logs the bonus; it does not update the wallet. For production, add DB access or an API call from the task.
2. **H2 in-memory DB:** Data is lost on app restart.
3. **No auth:** No authentication on REST endpoints.
4. **External dependency:** `vip.appcity:celery-spring-boot-starter` must be available from your Maven repositories.

---

## Quick API Test

```bash
# Create wallet
curl -X POST http://localhost:8080/wallet/create/user1

# Deposit (triggers 10% bonus Celery task)
curl -X POST "http://localhost:8080/wallet/deposit/user1?amount=100"

# Check balance
curl http://localhost:8080/wallet/balance/user1
```

