package com.example.walletmanagement.controller;

import com.example.walletmanagement.entity.Wallet;
import com.example.walletmanagement.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/wallet")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @PostMapping("/create/{userId}")
    public ResponseEntity<Wallet> createWallet(@PathVariable String userId) {
        Wallet wallet = walletService.createWallet(userId);
        return ResponseEntity.ok(wallet);
    }

    @GetMapping("/balance/{userId}")
    public ResponseEntity<BigDecimal> getBalance(@PathVariable String userId) {
        BigDecimal balance = walletService.getBalance(userId);
        return ResponseEntity.ok(balance);
    }

    @PostMapping("/deposit/{userId}")
    public ResponseEntity<Wallet> deposit(@PathVariable String userId, @RequestParam BigDecimal amount) {
        Wallet wallet = walletService.deposit(userId, amount);
        // After deposit, trigger Celery task for 10% bonus
        BigDecimal bonus = amount.multiply(BigDecimal.valueOf(0.1));
        walletService.submitRewardTask(userId, bonus);
        return ResponseEntity.ok(wallet);
    }

    @PostMapping("/withdraw/{userId}")
    public ResponseEntity<?> withdraw(@PathVariable String userId, @RequestParam BigDecimal amount) {
        try {
            Wallet wallet = walletService.withdraw(userId, amount);
            return ResponseEntity.ok(wallet);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
