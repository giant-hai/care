package com.example.walletmanagement.service;

import com.example.walletmanagement.entity.Wallet;
import com.example.walletmanagement.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vip.appcity.celery.Celery;
import org.springframework.beans.factory.annotation.Value;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class WalletService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private Celery celery;

    @Value("${celery.queue:reward-queue}")
    private String rewardQueue;

    public Wallet createWallet(String userId) {
        Wallet wallet = new Wallet();
        wallet.setUserId(userId);
        wallet.setBalance(BigDecimal.ZERO);
        return walletRepository.save(wallet);
    }

    public Optional<Wallet> getWallet(String userId) {
        return walletRepository.findByUserId(userId);
    }

    public BigDecimal getBalance(String userId) {
        return getWallet(userId)
                .map(Wallet::getBalance)
                .orElse(BigDecimal.ZERO);
    }

    public void submitRewardTask(String userId, BigDecimal bonus) {
        // Submit Celery task to reward-queue
        celery.submit("process_reward", new Object[]{userId, bonus.toString()}, rewardQueue);
    }

    public Wallet deposit(String userId, BigDecimal amount) {
        Wallet wallet = getWallet(userId).orElseThrow(() -> new IllegalArgumentException("Wallet not found"));
        wallet.setBalance(wallet.getBalance().add(amount));
        return walletRepository.save(wallet);
    }

    public Wallet withdraw(String userId, BigDecimal amount) {
        Wallet wallet = getWallet(userId).orElseThrow(() -> new IllegalArgumentException("Wallet not found"));
        if (wallet.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient balance");
        }
        wallet.setBalance(wallet.getBalance().subtract(amount));
        return walletRepository.save(wallet);
    }
}
