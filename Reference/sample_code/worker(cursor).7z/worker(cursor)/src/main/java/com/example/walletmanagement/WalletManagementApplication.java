package com.example.walletmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Wallet Management Spring Boot application.
 * Runs the wallet management REST API and integrates with Celery for background tasks.
 */
@SpringBootApplication
public class WalletManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(WalletManagementApplication.class, args);
    }

}
