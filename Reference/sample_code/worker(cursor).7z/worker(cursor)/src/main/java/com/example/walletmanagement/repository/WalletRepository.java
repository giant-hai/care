package com.example.walletmanagement.repository;

import com.example.walletmanagement.entity.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repository for Wallet entity.
 * Provides methods to find wallets by userId.
 */
public interface WalletRepository extends JpaRepository<Wallet, Long> {
    /**
     * Find a wallet by userId.
     * @param userId the user's unique identifier
     * @return Optional containing the wallet if found
     */
    Optional<Wallet> findByUserId(String userId);
}
