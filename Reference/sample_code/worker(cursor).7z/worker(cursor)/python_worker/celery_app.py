import os
from celery import Celery

broker_url = os.environ.get('CELERY_BROKER_URL', 'amqp://guest:guest@localhost:5672//')
app = Celery('wallet_worker', broker=broker_url)
app.conf.task_queues = {
    'reward-queue': {
        'exchange': 'reward-queue',
        'routing_key': 'reward-queue',
    }
}
