from celery_app import app

@app.task(bind=True)
def process_reward(self, user_id, bonus):
    print(f"Processing reward for user {user_id}: bonus {bonus}")
    # Simulate callback/API call to add bonus
    # In production, update DB or call service
