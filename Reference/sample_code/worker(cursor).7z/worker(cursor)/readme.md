# Wallet Management Sample Project

This is a simple sample project demonstrating a wallet management system built with Java Spring Boot. It handles basic operations like creating wallets, depositing/withdrawing funds, and checking balances. For asynchronous background processing (e.g., rewarding payments such as adding bonuses after deposits), it integrates with Celery (Python-based) using RabbitMQ as the message broker. The integration is facilitated by the celery-spring-boot-starter library (group: vip.appcity), which allows the Spring Boot application to submit tasks directly to Celery queues.

The setup supports a microservices architecture where multiple services can communicate via RabbitMQ/Celery tasks.

## Features

- REST API for wallet operations (create, deposit, withdraw, balance check).
- Asynchronous reward processing: After a deposit, a 10% bonus is calculated and added via a background Celery task.
- Uses H2 in-memory database for simplicity (can be swapped for PostgreSQL/MySQL).
- RabbitMQ for messaging.
- Hybrid Java-Python setup: Spring Boot as the core service, Python Celery for scalable background workers.

## Prerequisites

- Java 17+ (JDK)
- Maven 3.6+
- Python 3.8+
- Docker (for running RabbitMQ)
- RabbitMQ (via Docker or local install)

## Project Structure

```
wallet-management/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/walletmanagement/
│   │   │       ├── config/         # RabbitMQ config (if custom)
│   │   │       ├── controller/     # REST controllers
│   │   │       ├── entity/         # JPA entities
│   │   │       ├── repository/     # Repositories
│   │   │       ├── service/        # Business logic
│   │   │       └── WalletManagementApplication.java
│   │   └── resources/
│   │       └── application.yml    # Config for DB, RabbitMQ, Celery
│   └── test/                      # Unit tests
├── python_worker/                 # Separate folder for Python Celery worker
│   ├── celery_app.py
│   ├── tasks.py
│   └── requirements.txt
├── pom.xml                        # Maven build file
├── README.md                      # This file
└── docker-compose.yml             # Optional: For running RabbitMQ and services
```

## Setup

### 1. Clone the Repository

```
git clone <your-repo-url>
cd wallet-management
```

### 2. Install Dependencies

- **Java** (Spring Boot API):
  ```bash
  mvn clean install
  ```

- **Python** (Celery worker):
  From the `python_worker/` folder:
  ```bash
  pip install -r requirements.txt
  ```
  (Requires `celery[rabbitmq]` in `requirements.txt` – already present.)

### 3. Configure Application

The default `src/main/resources/application.yml` is already set up for local development:

- H2 in-memory DB
- RabbitMQ on `localhost:5672` (guest/guest)
- Celery broker `amqp://guest:guest@localhost:5672//`

You can customize it as needed; see the file for details.

### 4. Start RabbitMQ (local)

You have two main options:

- **Install RabbitMQ locally** (no Docker) – recommended for full-local mode.  
  See `READINESS.md` → “Option A: Fully local (no Docker at all)”.

- **Run RabbitMQ via Docker**:
  ```bash
  docker run -d -p 5672:5672 -p 15672:15672 --name rabbitmq rabbitmq:3-management
  ```
  Management UI: [http://localhost:15672](http://localhost:15672) (guest/guest).

## Running the Application

There are multiple run modes; for a detailed readiness overview see `READINESS.md`.

### Option A: Fully local (no Docker)

1. **RabbitMQ** – install & run locally (see `READINESS.md` for OS-specific notes).
2. **Spring Boot API** (from project root):
   ```bash
   mvn spring-boot:run
   ```
3. **Celery worker**:
   ```bash
   cd python_worker
   celery -A celery_app worker -Q reward-queue --loglevel=info
   ```

The API will be available at [http://localhost:8080](http://localhost:8080).

### Option B: Local app + RabbitMQ via Docker

1. Start RabbitMQ with Docker (see above).
2. Start Spring Boot and Celery as in **Option A**.

### Option C: Docker Compose (full stack in containers)

See the **Docker Compose** section below.

## API Endpoints

Use tools like Postman or curl to test.

- **Create Wallet**: POST /wallet/create/{userId} Example: curl -X POST http://localhost:8080/wallet/create/user1
- **Get Balance**: GET /wallet/balance/{userId} Example: curl http://localhost:8080/wallet/balance/user1
- **Deposit**: POST /wallet/deposit/{userId}?amount={amount} Example: curl -X POST "http://localhost:8080/wallet/deposit/user1?amount=100" (Triggers Celery task for 10% bonus asynchronously)
- **Withdraw**: POST /wallet/withdraw/{userId}?amount={amount} Example: curl -X POST "http://localhost:8080/wallet/withdraw/user1?amount=50"

## Background Worker Details

- When a deposit occurs, the WalletService submits a task to Celery using celery.submit("process_reward", new Object[]{userId, bonus.toString()}).
- The Python task process_reward processes the bonus (logs it and simulates an API callback to add the bonus; in production, use shared DB or proper integration).
- For error handling/retries: Celery supports built-in retries (configure in tasks.py with @app.task(bind=True, retry_backoff=True)).

## Docker Compose (Optional)

To run everything in containers, use the provided `docker-compose.yml`:

```
version: '3'
services:
  rabbitmq:
    image: rabbitmq:3-management
    ports:
      - "5672:5672"
      - "15672:15672"

  spring-app:
    build: .
    ports:
      - "8080:8080"
    depends_on:
      - rabbitmq
    environment:
      SPRING_RABBITMQ_HOST: rabbitmq
      CELERY_BROKER: amqp://guest:guest@rabbitmq:5672//

  celery-worker:
    build: ./python_worker
    command: celery -A celery_app worker -Q reward-queue --loglevel=info
    depends_on:
      - rabbitmq
    environment:
      CELERY_BROKER_URL: amqp://guest:guest@rabbitmq:5672//
```

- Build & run:
  ```bash
  docker-compose up --build
  ```
- RabbitMQ UI: [http://localhost:15672](http://localhost:15672) (guest/guest)
- API: [http://localhost:8080](http://localhost:8080)

## Testing

- Unit tests: Run mvn test.
- Integration: After starting services, test deposits and monitor Celery logs for reward processing.

## Extending for Microservices

- Add more queues/tasks for inter-service communication (e.g., a payment gateway service submitting tasks to payment-queue).
- Use enableMultiQueue: true in Celery config for task-specific queues.

## Dependencies

- Spring Boot: Web, JPA, AMQP, Lombok
- Celery Starter: vip.appcity:celery-spring-boot-starter (check Maven Central for version)
- H2 Database (runtime)
- Python: Celery with RabbitMQ bundle

## Limitations

- In-memory DB: Data resets on restart.
- Security: No auth implemented (add Spring Security for production).
- Error Handling: Basic; enhance with try-catch and Celery retries.
- Callback: The Celery task uses a simulated HTTP callback; for real use, share a database or use message replies.

## License

MIT License. Feel free to use and modify.

For questions, contact the maintainer.