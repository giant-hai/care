package com.jobboard.jobs.enums;

public enum JobCategory {
    SOFTWARE_DEVELOPMENT,
    DATA_SCIENCE,
    DESIGN,
    MARKETING,
    SALES,
    HR,
    FINANCE,
    OPERATIONS,
    CUSTOMER_SUPPORT,
    OTHER
}