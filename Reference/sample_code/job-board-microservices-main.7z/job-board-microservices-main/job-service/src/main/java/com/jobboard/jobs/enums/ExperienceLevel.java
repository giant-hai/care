package com.jobboard.jobs.enums;

public enum ExperienceLevel {
    ENTRY_LEVEL,
    INTERMEDIATE,
    SENIOR,
    LEAD,
    EXECUTIVE
}