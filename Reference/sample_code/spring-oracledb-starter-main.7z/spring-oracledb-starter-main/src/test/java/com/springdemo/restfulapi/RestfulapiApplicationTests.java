package com.springdemo.restfulapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
